/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input unary numbers
        System.out.print("Enter first unary number: ");
        String u1 = sc.nextLine();

        System.out.print("Enter second unary number: ");
        String u2 = sc.nextLine();

        // Unary addition = concatenation
        String sum = u1 + u2;

        System.out.println("Unary Sum: " + sum);

        sc.close();
    }
}


/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input number
        System.out.print("Enter the number: ");
        int number = sc.nextInt();

        // Digit to find
        System.out.print("Enter the digit to find: ");
        int findDigit = sc.nextInt();

        // Digit to replace with
        System.out.print("Enter the digit to replace with: ");
        int replaceDigit = sc.nextInt();

        int result = 0;
        int place = 1;

        while (number > 0) {
            int digit = number % 10;

            if (digit == findDigit) {
                digit = replaceDigit;
            }

            result = result + digit * place;
            place = place * 10;
            number = number / 10;
        }

        System.out.println("Result after replacement: " + result);
    }
}


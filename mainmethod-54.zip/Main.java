/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		
	public class Mainmethod {


        friends();
    }

    public static void friends() {
        Surya();
        Minikki();
        Vinothini();
        Manjima();
        Dhanya();
        Sri();
        Ranjanasri();
    }

    public static void Surya() {
        System.out.println("Surya, Su");
    }

    public static void Minikki() {
        System.out.println("Minikki, Silk");
    }

    public static void Vinothini() {
        System.out.println("Pen");
    }

    public static void Manjima() {
        System.out.println("Kutta");
    }

    public static void Dhanya() {
        System.out.println("Palalagii");
    }

    public static void Sri() {
        System.out.println("Tall");
    }

    public static void Ranjanasri() {
        System.out.println("Blacky");
    }
}

